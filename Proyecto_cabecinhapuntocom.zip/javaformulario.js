
function myFunction() {
    document.getElementById("myForm").submit();
}
